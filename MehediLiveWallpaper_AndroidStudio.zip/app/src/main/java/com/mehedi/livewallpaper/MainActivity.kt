package com.mehedi.livewallpaper

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
        }
        layout.addView(TextView(this).apply {
            text = "Mehedi Live Wallpaper\\n\\nআপনার ছবির সঙ্গে দিন-রাত ও আবহাওয়ার প্রভাব।\\n\\nওয়ালপেপার চালু করতে নিচের বোতাম চাপুন।"
            textSize = 20f
        })
        layout.addView(Button(this).apply {
            text = "লাইভ ওয়ালপেপার সেট করুন"
            setOnClickListener {
                val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                    putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        ComponentName(this@MainActivity, WeatherWallpaperService::class.java))
                }
                startActivity(intent)
            }
        })
        setContentView(layout)
    }
}
