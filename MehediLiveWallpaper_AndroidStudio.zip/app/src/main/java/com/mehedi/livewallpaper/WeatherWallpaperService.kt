package com.mehedi.livewallpaper

import android.Manifest
import android.app.WallpaperManager
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import android.location.Location
import android.location.LocationManager
import android.content.Context
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import kotlin.concurrent.thread
import kotlin.random.Random

class WeatherWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = WeatherEngine()

    inner class WeatherEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private var bitmap: Bitmap? = null
        private var weatherCode = -1
        private var isRaining = false
        private var lastWeatherCheck = 0L
        private val rain = ArrayList<PointF>()
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val tick = object : Runnable {
            override fun run() {
                drawFrame()
                if (visible) handler.postDelayed(this, 1000L / 20L)
            }
        }

        init {
            try {
                assets.open("wallpaper.png").use { bitmap = BitmapFactory.decodeStream(it) }
            } catch (_: Exception) {}
            repeat(90) {
                rain.add(PointF(Random.nextFloat(), Random.nextFloat()))
            }
            updateWeatherIfNeeded()
        }

        override fun onVisibilityChanged(visibleNow: Boolean) {
            visible = visibleNow
            if (visibleNow) {
                updateWeatherIfNeeded()
                handler.removeCallbacks(tick)
                handler.post(tick)
            } else handler.removeCallbacks(tick)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(tick)
            bitmap?.recycle()
            bitmap = null
            super.onDestroy()
        }

        private fun updateWeatherIfNeeded() {
            val now = System.currentTimeMillis()
            if (now - lastWeatherCheck < 30 * 60 * 1000L) return
            lastWeatherCheck = now
            thread {
                try {
                    val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
                    var loc: Location? = null
                    val fine = ContextCompat.checkSelfPermission(this@WeatherWallpaperService, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    val coarse = ContextCompat.checkSelfPermission(this@WeatherWallpaperService, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    if (fine || coarse) {
                        for (provider in listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)) {
                            try {
                                val candidate = lm.getLastKnownLocation(provider)
                                if (candidate != null && (loc == null || candidate.time > loc!!.time)) loc = candidate
                            } catch (_: Exception) {}
                        }
                    }
                    // Fallback coordinates for Savar, Bangladesh if location permission/location is unavailable.
                    val lat = loc?.latitude ?: 23.8583
                    val lon = loc?.longitude ?: 90.2667
                    val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=weather_code,is_day&timezone=auto")
                    val conn = (url.openConnection() as HttpURLConnection).apply {
                        connectTimeout = 5000; readTimeout = 5000; requestMethod = "GET"
                    }
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    conn.disconnect()
                    val current = JSONObject(body).getJSONObject("current")
                    val code = current.optInt("weather_code", -1)
                    val rainNow = code in setOf(51,53,55,56,57,61,63,65,66,67,80,81,82,95,96,99)
                    handler.post { weatherCode = code; isRaining = rainNow; if (visible) drawFrame() }
                } catch (_: Exception) {
                    // If network/weather is unavailable, time-based day/night still works.
                }
            }
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    val w = canvas.width.toFloat()
                    val h = canvas.height.toFloat()
                    val bmp = bitmap
                    if (bmp != null) {
                        val scale = maxOf(w / bmp.width, h / bmp.height)
                        val dw = bmp.width * scale
                        val dh = bmp.height * scale
                        val left = (w - dw) / 2f
                        val top = (h - dh) / 2f
                        paint.colorFilter = null
                        canvas.drawBitmap(bmp, null, RectF(left, top, left + dw, top + dh), paint)
                    } else canvas.drawColor(Color.DKGRAY)

                    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                    val night = hour < 6 || hour >= 19
                    if (night) {
                        paint.color = Color.argb(105, 5, 14, 45)
                        canvas.drawRect(0f, 0f, w, h, paint)
                        // Subtle moon in upper sky.
                        paint.color = Color.argb(220, 245, 244, 220)
                        canvas.drawCircle(w * 0.78f, h * 0.12f, w * 0.035f, paint)
                        paint.color = Color.argb(110, 8, 20, 52)
                        canvas.drawCircle(w * 0.795f, h * 0.105f, w * 0.032f, paint)
                        paint.color = Color.argb(150, 255, 255, 255)
                        repeat(22) { i ->
                            val x = ((i * 83 + 29) % 997) / 997f * w
                            val y = ((i * 47 + 13) % 260) / 1000f * h
                            canvas.drawCircle(x, y, 1.5f, paint)
                        }
                    } else {
                        paint.color = Color.argb(18, 255, 220, 100)
                        canvas.drawRect(0f, 0f, w, h, paint)
                    }
                    if (isRaining) {
                        paint.color = Color.argb(150, 25, 35, 48)
                        canvas.drawRect(0f, 0f, w, h, paint)
                        paint.color = Color.argb(155, 210, 230, 255)
                        paint.strokeWidth = 2f
                        rain.forEach {
                            val x = it.x * w
                            val y = it.y * h
                            canvas.drawLine(x, y, x - w * 0.012f, y + h * 0.025f, paint)
                            it.y += 0.025f
                            it.x -= 0.004f
                            if (it.y > 1f || it.x < 0f) {
                                it.x = Random.nextFloat()
                                it.y = -Random.nextFloat() * 0.2f
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                if (canvas != null) try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
            }
        }
    }
}
